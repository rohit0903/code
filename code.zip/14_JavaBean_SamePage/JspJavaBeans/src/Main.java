/*
public class Main {
	public static void main(String args[]) {

		Employee e = new Employee();// object is created

		e.setName("Rohit");// setting value to the object

		System.out.println(e.getName());

	}
}
*/